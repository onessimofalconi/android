package schirmer.nicolas.aula6;

import android.graphics.Bitmap;

public interface DownloadListener {

    void getImg(Bitmap bitmap);
}
